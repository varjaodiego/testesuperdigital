﻿
namespace superdigital.conta.model
{
    public class AppConnectionSettings
    {
        public string DefaultConnection { get; set; }
        public string Db { get; set; }
    }
}
