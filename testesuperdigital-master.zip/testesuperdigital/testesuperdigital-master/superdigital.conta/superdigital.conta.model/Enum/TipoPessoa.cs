﻿
namespace superdigital.conta.model.Enum
{
    public enum TipoPessoa
    {
        Fisica = 1,
        Juridico = 2
    }
}
