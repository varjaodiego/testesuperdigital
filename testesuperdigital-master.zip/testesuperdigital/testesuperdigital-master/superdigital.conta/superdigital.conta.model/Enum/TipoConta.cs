﻿
namespace superdigital.conta.model.Enum
{
    public enum TipoConta
    {
        Corrente = 1,
        Poupanca = 2,
        Investimento = 3
    }
}
